//
//  HomeCollectionViewCell.swift
//  Plannerv3
//
//  Created by user252544 on 5/5/24.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imgProductPhoto: UIImageView!
}
